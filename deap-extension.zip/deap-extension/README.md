# BER Survey DEAP Fill (Chrome extension)

Fills the DEAP screen you have open at deap.seai.ie with the values from a BER Survey. It only types into fields. It never presses Save, Next or anything else in DEAP, so you check each screen and save it yourself.

## Install (once, on the laptop)

1. Download https://greenfieldspaces.github.io/BER-Survey/deap-extension.zip and unzip it. Keep the unzipped folder somewhere it will stay, such as Documents.
2. In Chrome go to `chrome://extensions`.
3. Turn on **Developer mode** (top right).
4. Click **Load unpacked** and choose the unzipped `deap-extension` folder.
5. Click the puzzle piece in the toolbar and pin **BER Survey DEAP Fill**.

To update later, unzip the new version over the same folder and press the reload arrow on the extension's card in `chrome://extensions`.

The extension has a fixed ID (`pimlmdoaefjfdbcccbijdeimiebpnkjp`), set by the `key` in manifest.json. Your settings, taught fields and remembered library picks are tied to that ID, so they survive if the folder is moved or renamed. If Chrome says a file is not found after a move, press **Remove** on the card and **Load unpacked** the folder from its new place; nothing is lost. Keep the `key` line when editing manifest.json.

## Use it

1. On the iPad, open the survey, go to **Enter in DEAP**, open **Fill DEAP from Chrome on your laptop** and tap **Share transfer file**. AirDrop, Mail or iCloud Drive it to the laptop.
2. On the laptop, log in to DEAP and open the assessment.
3. Click the extension icon. The side panel opens. Drop in the transfer file (or paste the transfer text).
4. Go to a DEAP screen. The panel switches to the same screen from your survey (or tap the screen name).
5. Press **Fill this DEAP screen**.
   - Green outline in DEAP and a green dot in the panel: filled.
   - Amber: DEAP already had a different value, so it was kept. Tick **Replace values already in DEAP** to overwrite.
   - Red: not found, or DEAP has no matching option. Tap the value to copy it and enter it by hand.
6. Check the screen and save it in DEAP.

DEAP adds walls, windows and other list items one at a time in a dialog. For those, press ADD WALL (or open an existing one) in DEAP, then press **Fill** on that row in the panel. Check it and save it in DEAP, then do the next row. Age bands are picked from the wall's year, or the dwelling's year if the wall has none.

## Transfer whole survey

With the survey loaded and the assessment open in DEAP, press **Start** under **Transfer whole survey**. It goes through Survey details, Floors, Roofs, Walls, Doors, Windows, Global factors, Ventilation (draught lobby, chimneys and fans, air tightness, method), Space heating (system type, controls, heat sources, pumps and fans), Water heating (combi, cylinder options, showers and baths, solar) and Solar PV:

- On ordinary screens it fills the values. DEAP saves those itself.
- For floors, roofs, walls, doors and windows it presses ADD, fills the dialog and presses SAVE, one at a time.
- Doors and windows need a DEAP library item first. The panel says **Your turn**: pick the library item and press ADD in DEAP, and the transfer carries on. **Skip this one** leaves that item out.
- Remembered picks: when it stops for you to pick a library item, the pick is remembered on this laptop (untick **Remember my pick** to skip that). The next survey with the same item, such as the same boiler or window type, gets it picked for you. At the end the panel lists **Picked for you from memory**. If one is wrong, fix it in DEAP and press **Forget**. **Remembered library picks** under the transfer lists them all, with Export and Import to move them to another laptop.
- If DEAP refuses to save a dialog, it waits for you to fix it and press SAVE.
- Library items (doors, windows, heat sources, chimneys and fans, showers and baths, solar collector): the panel says **Your turn** and types a search into DEAP's library for you. Pick the item and press ADD; it fills and saves the dialog that follows (fuel and "heats water" for heat sources, number, area and so on).
- When it finishes, **Count check** at the top shows, for floors, roofs, walls, doors, windows, chimneys and fans, heat sources, showers and baths, solar and evidence photos, how many the survey has against how many went into DEAP, such as "Windows 31 of 32". Anything short is orange, names the item and why, and has a link to open that DEAP screen. The run report has the same counts.
- When it finishes, it lists what is left to check or do by hand, such as the boiler efficiency, which comes from the library item you picked.

- Evidence photos: if the transfer file has your site photos and sketches (the app adds them unless you untick **Send the photos too**), the last step opens DEAP's Evidence screen and uploads them one at a time, named by their captions. If DEAP asks about a file, the panel says **Your turn**: fill it in and press SAVE in DEAP. Anything that does not upload is saved to your Downloads folder in "BER evidence - <survey name>" for you to drag onto "Drop file(s) here".

It never presses Publish, Submit, Delete or Download. Untick any section that is already in DEAP so it is not added twice. **Stop** halts it at any point.

## Teaching it DEAP's fields

The first version matches DEAP fields by their labels, using best guesses from the SEAI DEAP Survey Guide. When a value is not found or lands in the wrong field:

1. Press **Pick** next to that value in the panel.
2. Click the right field in DEAP.

It remembers that field for every survey on this laptop. For a table column, press **Pick** under the column heading and click that column's field in any row.

Under **Setup and troubleshooting**:

- **List fields on this DEAP page** shows every field the extension can see, with its label. **Copy list** and send it to Claude to improve the built-in matching.
- **Export taught fields** saves what you have taught as a file, to back it up, move it to another laptop, or send to Claude so it can be built in.

## Files

- `manifest.json`: Chrome extension settings. It only runs on https://deap.seai.ie.
- `sidepanel.*`: the panel.
- `content.js`: runs in the DEAP page. Finds fields, fills them, outlines them.
- `mapping.json`: built-in guesses at DEAP's label for each survey value. `labels` are label texts to look for, `selector` pins an exact field, `values` maps a survey answer to DEAP's wording, `skip` leaves a value out.
